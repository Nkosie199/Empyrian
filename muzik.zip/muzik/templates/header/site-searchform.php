<?php
/**
 * Search form
 */
?>
<form class="search-form" method="get" action="<?php echo esc_url(home_url()); ?>">
	<input type="search" placeholder="<?php esc_attr_e('Search...','muzik'); ?>" value="" name="s" data-toggle="dropdown" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">
	<label for="search-state" id="icon-search">
		<i class="icon-search"><i></i></i>
	</label>
	<div class="dropdown-menu"></div>
</form>
