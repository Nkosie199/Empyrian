<?php
/**
 * Displays header site navbar
 */
?>
<!-- <div class="site-headbar">
	<p>Mock header, user can add custom html here</p>
</div> -->
<div class="header-container">
	<div class="site-navbar">
		<?php get_template_part( 'templates/header/site', 'brand', array('menu'=>'navbar') ); ?>
		<div class="flex"></div>
		<?php get_template_part( 'templates/header/site', 'searchform' ); ?>
		<div class="flex"></div>

		<?php if ( has_nav_menu( 'secondary' ) ) : ?>
			<nav id="secondary-menu" class="secondary-menu">
				<label id="icon-nav"> ⋯ </label>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'secondary',
						'menu_class'     => 'nav',
						'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					)
				);
				?>
			</nav>
		<?php endif; ?>

		<?php if ( !is_user_logged_in() && has_nav_menu( 'before_login' ) ) : ?>
			<nav class="menu-before-login">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'before_login',
						'menu_class'     => 'nav',
						'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					)
				);
				?>
			</nav>
		<?php endif; ?>
		
		<?php if ( is_user_logged_in() && has_nav_menu( 'after_login' ) ) : ?>
			<nav class="menu-after-login">
				<?php
				do_action('menu_after_login_before');
				wp_nav_menu(
					array(
						'theme_location' => 'after_login',
						'menu_class'     => 'nav',
						'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					)
				);
				do_action('menu_after_login_after');
				?>
			</nav>
		<?php endif; ?>
	</div>
</div>
