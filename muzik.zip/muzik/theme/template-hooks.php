<?php
/**
 * Hooks
 */

// required plugins
add_filter('ffl_required_plugins', 'ffl_required_plugins');
function ffl_required_plugins($args){
	$args[] = array(
		'name'      => 'Easy Digital Downloads',
        'slug'      => 'easy-digital-downloads',
        'required'  => true
	);
	return $args;
}

add_action( 'wp_enqueue_scripts', 'ffl_theme_scripts' );
if ( ! function_exists( 'ffl_theme_scripts' ) ) :
function ffl_theme_scripts() {
	wp_enqueue_style( 'ffl-custom-style', get_theme_file_uri().'/theme/theme.css', array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'ffl-theme-script', get_theme_file_uri().'/theme/theme.js', array('jquery'), wp_get_theme()->get( 'Version' ), true );
}
endif;

add_filter( 'player_theme', 'ffl_player_theme' );
if ( ! function_exists( 'ffl_player_theme' ) ) :
function ffl_player_theme(){
	return '';
}
endif;

add_filter('play_user_desc_moreless', '__return_true');
add_filter('play_content_moreless', '__return_true');
add_filter('play_output_info_author', '__return_true');

remove_action( 'play_single_meta', 'play_output_author', 70);
remove_action( 'play_before_single_title', 'play_output_artist', 10 );
remove_action( 'after_loop_header', 'play_output_purchase_btn', 50);
remove_action( 'play_after_content', 'play_output_tracks');
remove_action( 'play_after_content', 'play_output_more', 20);
remove_action( 'play_after_content', 'play_output_similar', 30);
remove_action( 'play_after_content', 'play_output_featured', 30);
remove_action( 'play_after_single_title', 'play_output_term', 200);
remove_action( 'play_single_header_end', 'play_output_editor_note', 30);
remove_action( 'play_single_header_end', 'play_output_copyright', 40);
remove_action( 'play_content', 'play_output_content', 10 );

add_action( 'play_single_content_start', 'play_output_more', 40);
add_action( 'play_single_content_start', 'play_output_similar', 50);
add_action( 'play_single_content_start', 'play_output_featured', 60);

add_action( 'play_before_single_title', 'play_output_tag', 10);
add_action( 'play_after_single_title',  'play_output_artist', 50);
add_action( 'play_after_single_title',  'play_output_info', 60);
add_action( 'play_after_single_title',  'play_output_content', 80);
add_action( 'play_after_single_header', 'play_output_waveform', 40);
add_action( 'play_single_content_start', 'play_output_editor_note', 20);
add_action( 'play_single_content_start', 'play_output_copyright', 30);
add_action( 'play_single_content_start', 'play_output_tracks', 10);
